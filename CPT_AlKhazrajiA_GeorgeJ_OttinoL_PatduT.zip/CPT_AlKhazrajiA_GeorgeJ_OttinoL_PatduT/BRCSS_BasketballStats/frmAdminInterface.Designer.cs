﻿namespace BRCSS_BasketballStats
{
    partial class frmAdminInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileStartResumeMatch = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileBorder = new System.Windows.Forms.ToolStripSeparator();
            this.mnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.tabTeamList = new System.Windows.Forms.TabControl();
            this.tabActiveTeams = new System.Windows.Forms.TabPage();
            this.txtActiveTeamsSearchBar = new System.Windows.Forms.TextBox();
            this.listActiveTeams = new System.Windows.Forms.ListBox();
            this.mnuActiveTeams = new System.Windows.Forms.MenuStrip();
            this.mnuActiveTeamsUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.tabArchive = new System.Windows.Forms.TabPage();
            this.txtArchivedTeamsSearchBar = new System.Windows.Forms.TextBox();
            this.listArchive = new System.Windows.Forms.ListBox();
            this.mnuArchivedTeams = new System.Windows.Forms.MenuStrip();
            this.mnuArchivedTeamsUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtMatchHistorySearchBar = new System.Windows.Forms.TextBox();
            this.listMatchHistory = new System.Windows.Forms.ListBox();
            this.grpPlayerProfile = new System.Windows.Forms.GroupBox();
            this.txtTeamBracket = new System.Windows.Forms.TextBox();
            this.lblTeamBracket = new System.Windows.Forms.Label();
            this.txtJerseyNumber = new System.Windows.Forms.TextBox();
            this.lblJerseyNumber = new System.Windows.Forms.Label();
            this.txtBasketballPosition = new System.Windows.Forms.TextBox();
            this.lblBasketballPosition = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.grpPlayerStats = new System.Windows.Forms.GroupBox();
            this.grpPlayerAveragesSection = new System.Windows.Forms.GroupBox();
            this.txt3PT_AVG = new System.Windows.Forms.TextBox();
            this.txtFT_AVG = new System.Windows.Forms.TextBox();
            this.txtAST_AVG = new System.Windows.Forms.TextBox();
            this.txt2PT_AVG = new System.Windows.Forms.TextBox();
            this.txtTIPP_AVG = new System.Windows.Forms.TextBox();
            this.txtBLK_AVG = new System.Windows.Forms.TextBox();
            this.txtPPG_AVG = new System.Windows.Forms.TextBox();
            this.txtTO_AVG = new System.Windows.Forms.TextBox();
            this.txtFLS_AVG = new System.Windows.Forms.TextBox();
            this.txtSTL_AVG = new System.Windows.Forms.TextBox();
            this.lblPPM_AVG = new System.Windows.Forms.Label();
            this.lblPPG_AVG = new System.Windows.Forms.Label();
            this.lblFT_AVG = new System.Windows.Forms.Label();
            this.lblTIPP_AVG = new System.Windows.Forms.Label();
            this.txtPPM_AVG = new System.Windows.Forms.TextBox();
            this.lblFLS_AVG = new System.Windows.Forms.Label();
            this.lblTO_AVG = new System.Windows.Forms.Label();
            this.lblAST_AVG = new System.Windows.Forms.Label();
            this.lblBLK_AVG = new System.Windows.Forms.Label();
            this.lblSTLS_AVG = new System.Windows.Forms.Label();
            this.lbl3PT_AVG = new System.Windows.Forms.Label();
            this.lbl2PT_AVG = new System.Windows.Forms.Label();
            this.grpPlayerOverallSection = new System.Windows.Forms.GroupBox();
            this.txtPER_OVRL = new System.Windows.Forms.TextBox();
            this.txtFDRWCMT_OVRL = new System.Windows.Forms.TextBox();
            this.txtMIN_OVRL = new System.Windows.Forms.TextBox();
            this.txt3PTMA_OVRL = new System.Windows.Forms.TextBox();
            this.txt2PTMA_OVRL = new System.Windows.Forms.TextBox();
            this.txtFTMA_OVRL = new System.Windows.Forms.TextBox();
            this.txtTIPP_OVRL = new System.Windows.Forms.TextBox();
            this.txtTO_OVRL = new System.Windows.Forms.TextBox();
            this.txtSTL_OVRL = new System.Windows.Forms.TextBox();
            this.txtBLK_OVRL = new System.Windows.Forms.TextBox();
            this.txtREB_OVRL = new System.Windows.Forms.TextBox();
            this.txtAST_OVRL = new System.Windows.Forms.TextBox();
            this.txtPTS_OVRL = new System.Windows.Forms.TextBox();
            this.lblPER_OVRL = new System.Windows.Forms.Label();
            this.lblFDRWCMT_OVRL = new System.Windows.Forms.Label();
            this.lblMIN_OVRL = new System.Windows.Forms.Label();
            this.lblTIPP_OVRL = new System.Windows.Forms.Label();
            this.lblFTMA_OVRL = new System.Windows.Forms.Label();
            this.lblTO_OVRL = new System.Windows.Forms.Label();
            this.lbl3PTMA_OVRL = new System.Windows.Forms.Label();
            this.lbl2PTMA_OVRL = new System.Windows.Forms.Label();
            this.lblSTL_OVRL = new System.Windows.Forms.Label();
            this.lblBLK_OVRL = new System.Windows.Forms.Label();
            this.lblAST_OVRL = new System.Windows.Forms.Label();
            this.lblREB_OVRL = new System.Windows.Forms.Label();
            this.lblPTS_OVRL = new System.Windows.Forms.Label();
            this.picPlayer = new System.Windows.Forms.PictureBox();
            this.mnuStrip.SuspendLayout();
            this.tabTeamList.SuspendLayout();
            this.tabActiveTeams.SuspendLayout();
            this.mnuActiveTeams.SuspendLayout();
            this.tabArchive.SuspendLayout();
            this.mnuArchivedTeams.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.grpPlayerProfile.SuspendLayout();
            this.grpPlayerStats.SuspendLayout();
            this.grpPlayerAveragesSection.SuspendLayout();
            this.grpPlayerOverallSection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuStrip
            // 
            this.mnuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile});
            this.mnuStrip.Location = new System.Drawing.Point(0, 0);
            this.mnuStrip.Name = "mnuStrip";
            this.mnuStrip.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.mnuStrip.Size = new System.Drawing.Size(750, 26);
            this.mnuStrip.TabIndex = 0;
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileStartResumeMatch,
            this.mnuFileBorder,
            this.mnuFileExit});
            this.mnuFile.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F);
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(40, 22);
            this.mnuFile.Text = "File";
            // 
            // mnuFileStartResumeMatch
            // 
            this.mnuFileStartResumeMatch.Name = "mnuFileStartResumeMatch";
            this.mnuFileStartResumeMatch.Size = new System.Drawing.Size(216, 26);
            this.mnuFileStartResumeMatch.Text = "Start / Resume Match";
            this.mnuFileStartResumeMatch.Click += new System.EventHandler(this.mnuFileStartMatch_Click);
            // 
            // mnuFileBorder
            // 
            this.mnuFileBorder.Name = "mnuFileBorder";
            this.mnuFileBorder.Size = new System.Drawing.Size(213, 6);
            // 
            // mnuFileExit
            // 
            this.mnuFileExit.Name = "mnuFileExit";
            this.mnuFileExit.Size = new System.Drawing.Size(216, 26);
            this.mnuFileExit.Text = "Exit";
            // 
            // tabTeamList
            // 
            this.tabTeamList.Controls.Add(this.tabActiveTeams);
            this.tabTeamList.Controls.Add(this.tabArchive);
            this.tabTeamList.Controls.Add(this.tabPage1);
            this.tabTeamList.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F);
            this.tabTeamList.Location = new System.Drawing.Point(334, 37);
            this.tabTeamList.Name = "tabTeamList";
            this.tabTeamList.SelectedIndex = 0;
            this.tabTeamList.Size = new System.Drawing.Size(405, 615);
            this.tabTeamList.TabIndex = 1;
            // 
            // tabActiveTeams
            // 
            this.tabActiveTeams.Controls.Add(this.txtActiveTeamsSearchBar);
            this.tabActiveTeams.Controls.Add(this.listActiveTeams);
            this.tabActiveTeams.Controls.Add(this.mnuActiveTeams);
            this.tabActiveTeams.Location = new System.Drawing.Point(4, 25);
            this.tabActiveTeams.Name = "tabActiveTeams";
            this.tabActiveTeams.Padding = new System.Windows.Forms.Padding(3);
            this.tabActiveTeams.Size = new System.Drawing.Size(397, 586);
            this.tabActiveTeams.TabIndex = 0;
            this.tabActiveTeams.Text = "Active Teams";
            this.tabActiveTeams.UseVisualStyleBackColor = true;
            // 
            // txtActiveTeamsSearchBar
            // 
            this.txtActiveTeamsSearchBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtActiveTeamsSearchBar.Location = new System.Drawing.Point(85, 6);
            this.txtActiveTeamsSearchBar.Name = "txtActiveTeamsSearchBar";
            this.txtActiveTeamsSearchBar.Size = new System.Drawing.Size(309, 24);
            this.txtActiveTeamsSearchBar.TabIndex = 1;
            // 
            // listActiveTeams
            // 
            this.listActiveTeams.FormattingEnabled = true;
            this.listActiveTeams.ItemHeight = 16;
            this.listActiveTeams.Location = new System.Drawing.Point(85, 34);
            this.listActiveTeams.Name = "listActiveTeams";
            this.listActiveTeams.ScrollAlwaysVisible = true;
            this.listActiveTeams.Size = new System.Drawing.Size(309, 548);
            this.listActiveTeams.TabIndex = 2;
            // 
            // mnuActiveTeams
            // 
            this.mnuActiveTeams.Dock = System.Windows.Forms.DockStyle.Left;
            this.mnuActiveTeams.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuActiveTeams.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuActiveTeamsUpdate});
            this.mnuActiveTeams.Location = new System.Drawing.Point(3, 3);
            this.mnuActiveTeams.Name = "mnuActiveTeams";
            this.mnuActiveTeams.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.mnuActiveTeams.Size = new System.Drawing.Size(79, 580);
            this.mnuActiveTeams.TabIndex = 0;
            this.mnuActiveTeams.Text = "mnuArchiveStrip";
            // 
            // mnuActiveTeamsUpdate
            // 
            this.mnuActiveTeamsUpdate.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F);
            this.mnuActiveTeamsUpdate.Name = "mnuActiveTeamsUpdate";
            this.mnuActiveTeamsUpdate.Size = new System.Drawing.Size(116, 22);
            this.mnuActiveTeamsUpdate.Text = "Update...";
            this.mnuActiveTeamsUpdate.Click += new System.EventHandler(this.mnuActiveTeamsUpdate_Click);
            // 
            // tabArchive
            // 
            this.tabArchive.Controls.Add(this.txtArchivedTeamsSearchBar);
            this.tabArchive.Controls.Add(this.listArchive);
            this.tabArchive.Controls.Add(this.mnuArchivedTeams);
            this.tabArchive.Location = new System.Drawing.Point(4, 25);
            this.tabArchive.Name = "tabArchive";
            this.tabArchive.Padding = new System.Windows.Forms.Padding(3);
            this.tabArchive.Size = new System.Drawing.Size(397, 586);
            this.tabArchive.TabIndex = 1;
            this.tabArchive.Text = "Archive";
            this.tabArchive.UseVisualStyleBackColor = true;
            // 
            // txtArchivedTeamsSearchBar
            // 
            this.txtArchivedTeamsSearchBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtArchivedTeamsSearchBar.Location = new System.Drawing.Point(85, 6);
            this.txtArchivedTeamsSearchBar.Name = "txtArchivedTeamsSearchBar";
            this.txtArchivedTeamsSearchBar.Size = new System.Drawing.Size(309, 24);
            this.txtArchivedTeamsSearchBar.TabIndex = 1;
            // 
            // listArchive
            // 
            this.listArchive.FormattingEnabled = true;
            this.listArchive.ItemHeight = 16;
            this.listArchive.Location = new System.Drawing.Point(85, 34);
            this.listArchive.Name = "listArchive";
            this.listArchive.ScrollAlwaysVisible = true;
            this.listArchive.Size = new System.Drawing.Size(309, 548);
            this.listArchive.TabIndex = 2;
            // 
            // mnuArchivedTeams
            // 
            this.mnuArchivedTeams.Dock = System.Windows.Forms.DockStyle.Left;
            this.mnuArchivedTeams.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuArchivedTeams.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArchivedTeamsUpdate});
            this.mnuArchivedTeams.Location = new System.Drawing.Point(3, 3);
            this.mnuArchivedTeams.Name = "mnuArchivedTeams";
            this.mnuArchivedTeams.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.mnuArchivedTeams.Size = new System.Drawing.Size(79, 580);
            this.mnuArchivedTeams.TabIndex = 0;
            this.mnuArchivedTeams.Text = "mnuArchiveStrip";
            // 
            // mnuArchivedTeamsUpdate
            // 
            this.mnuArchivedTeamsUpdate.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F);
            this.mnuArchivedTeamsUpdate.Name = "mnuArchivedTeamsUpdate";
            this.mnuArchivedTeamsUpdate.Size = new System.Drawing.Size(116, 22);
            this.mnuArchivedTeamsUpdate.Text = "Update...";
            this.mnuArchivedTeamsUpdate.Click += new System.EventHandler(this.mnuArchivedTeamsUpdate_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtMatchHistorySearchBar);
            this.tabPage1.Controls.Add(this.listMatchHistory);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(397, 586);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Match History";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtMatchHistorySearchBar
            // 
            this.txtMatchHistorySearchBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMatchHistorySearchBar.Location = new System.Drawing.Point(6, 6);
            this.txtMatchHistorySearchBar.Name = "txtMatchHistorySearchBar";
            this.txtMatchHistorySearchBar.Size = new System.Drawing.Size(388, 24);
            this.txtMatchHistorySearchBar.TabIndex = 1;
            // 
            // listMatchHistory
            // 
            this.listMatchHistory.FormattingEnabled = true;
            this.listMatchHistory.ItemHeight = 16;
            this.listMatchHistory.Location = new System.Drawing.Point(6, 34);
            this.listMatchHistory.Name = "listMatchHistory";
            this.listMatchHistory.ScrollAlwaysVisible = true;
            this.listMatchHistory.Size = new System.Drawing.Size(387, 548);
            this.listMatchHistory.TabIndex = 2;
            // 
            // grpPlayerProfile
            // 
            this.grpPlayerProfile.Controls.Add(this.txtTeamBracket);
            this.grpPlayerProfile.Controls.Add(this.lblTeamBracket);
            this.grpPlayerProfile.Controls.Add(this.txtJerseyNumber);
            this.grpPlayerProfile.Controls.Add(this.lblJerseyNumber);
            this.grpPlayerProfile.Controls.Add(this.txtBasketballPosition);
            this.grpPlayerProfile.Controls.Add(this.lblBasketballPosition);
            this.grpPlayerProfile.Controls.Add(this.txtName);
            this.grpPlayerProfile.Controls.Add(this.lblName);
            this.grpPlayerProfile.Controls.Add(this.grpPlayerStats);
            this.grpPlayerProfile.Controls.Add(this.picPlayer);
            this.grpPlayerProfile.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F);
            this.grpPlayerProfile.Location = new System.Drawing.Point(11, 31);
            this.grpPlayerProfile.Name = "grpPlayerProfile";
            this.grpPlayerProfile.Size = new System.Drawing.Size(318, 621);
            this.grpPlayerProfile.TabIndex = 0;
            this.grpPlayerProfile.TabStop = false;
            this.grpPlayerProfile.Text = "Player Profile";
            // 
            // txtTeamBracket
            // 
            this.txtTeamBracket.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTeamBracket.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtTeamBracket.Location = new System.Drawing.Point(150, 164);
            this.txtTeamBracket.Name = "txtTeamBracket";
            this.txtTeamBracket.ReadOnly = true;
            this.txtTeamBracket.Size = new System.Drawing.Size(160, 20);
            this.txtTeamBracket.TabIndex = 3;
            // 
            // lblTeamBracket
            // 
            this.lblTeamBracket.AutoSize = true;
            this.lblTeamBracket.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTeamBracket.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBracket.Location = new System.Drawing.Point(150, 146);
            this.lblTeamBracket.Name = "lblTeamBracket";
            this.lblTeamBracket.Size = new System.Drawing.Size(77, 15);
            this.lblTeamBracket.TabIndex = 44;
            this.lblTeamBracket.Text = "TEAM BRACKET";
            // 
            // txtJerseyNumber
            // 
            this.txtJerseyNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtJerseyNumber.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtJerseyNumber.Location = new System.Drawing.Point(150, 123);
            this.txtJerseyNumber.Name = "txtJerseyNumber";
            this.txtJerseyNumber.ReadOnly = true;
            this.txtJerseyNumber.Size = new System.Drawing.Size(160, 20);
            this.txtJerseyNumber.TabIndex = 2;
            // 
            // lblJerseyNumber
            // 
            this.lblJerseyNumber.AutoSize = true;
            this.lblJerseyNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblJerseyNumber.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJerseyNumber.Location = new System.Drawing.Point(150, 105);
            this.lblJerseyNumber.Name = "lblJerseyNumber";
            this.lblJerseyNumber.Size = new System.Drawing.Size(83, 15);
            this.lblJerseyNumber.TabIndex = 42;
            this.lblJerseyNumber.Text = "JERSEY NUMBER";
            // 
            // txtBasketballPosition
            // 
            this.txtBasketballPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBasketballPosition.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtBasketballPosition.Location = new System.Drawing.Point(150, 82);
            this.txtBasketballPosition.Name = "txtBasketballPosition";
            this.txtBasketballPosition.ReadOnly = true;
            this.txtBasketballPosition.Size = new System.Drawing.Size(160, 20);
            this.txtBasketballPosition.TabIndex = 1;
            // 
            // lblBasketballPosition
            // 
            this.lblBasketballPosition.AutoSize = true;
            this.lblBasketballPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBasketballPosition.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBasketballPosition.Location = new System.Drawing.Point(150, 64);
            this.lblBasketballPosition.Name = "lblBasketballPosition";
            this.lblBasketballPosition.Size = new System.Drawing.Size(112, 15);
            this.lblBasketballPosition.TabIndex = 40;
            this.lblBasketballPosition.Text = "BASKETBALL POSITION";
            // 
            // txtName
            // 
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtName.Location = new System.Drawing.Point(150, 40);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(160, 20);
            this.txtName.TabIndex = 0;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(150, 22);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(36, 15);
            this.lblName.TabIndex = 39;
            this.lblName.Text = "NAME";
            // 
            // grpPlayerStats
            // 
            this.grpPlayerStats.Controls.Add(this.grpPlayerAveragesSection);
            this.grpPlayerStats.Controls.Add(this.grpPlayerOverallSection);
            this.grpPlayerStats.Location = new System.Drawing.Point(5, 190);
            this.grpPlayerStats.Name = "grpPlayerStats";
            this.grpPlayerStats.Size = new System.Drawing.Size(307, 422);
            this.grpPlayerStats.TabIndex = 4;
            this.grpPlayerStats.TabStop = false;
            this.grpPlayerStats.Text = "Player Statistics";
            // 
            // grpPlayerAveragesSection
            // 
            this.grpPlayerAveragesSection.Controls.Add(this.txt3PT_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtFT_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtAST_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txt2PT_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtTIPP_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtBLK_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtPPG_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtTO_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtFLS_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtSTL_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblPPM_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblPPG_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblFT_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblTIPP_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.txtPPM_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblFLS_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblTO_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblAST_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblBLK_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lblSTLS_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lbl3PT_AVG);
            this.grpPlayerAveragesSection.Controls.Add(this.lbl2PT_AVG);
            this.grpPlayerAveragesSection.Location = new System.Drawing.Point(5, 230);
            this.grpPlayerAveragesSection.Name = "grpPlayerAveragesSection";
            this.grpPlayerAveragesSection.Size = new System.Drawing.Size(297, 184);
            this.grpPlayerAveragesSection.TabIndex = 1;
            this.grpPlayerAveragesSection.TabStop = false;
            this.grpPlayerAveragesSection.Text = "Averages";
            // 
            // txt3PT_AVG
            // 
            this.txt3PT_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt3PT_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txt3PT_AVG.Location = new System.Drawing.Point(31, 159);
            this.txt3PT_AVG.Name = "txt3PT_AVG";
            this.txt3PT_AVG.ReadOnly = true;
            this.txt3PT_AVG.Size = new System.Drawing.Size(68, 20);
            this.txt3PT_AVG.TabIndex = 0;
            this.txt3PT_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFT_AVG
            // 
            this.txtFT_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFT_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtFT_AVG.Location = new System.Drawing.Point(189, 118);
            this.txtFT_AVG.Name = "txtFT_AVG";
            this.txtFT_AVG.ReadOnly = true;
            this.txtFT_AVG.Size = new System.Drawing.Size(88, 20);
            this.txtFT_AVG.TabIndex = 8;
            this.txtFT_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAST_AVG
            // 
            this.txtAST_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAST_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtAST_AVG.Location = new System.Drawing.Point(105, 118);
            this.txtAST_AVG.Name = "txtAST_AVG";
            this.txtAST_AVG.ReadOnly = true;
            this.txtAST_AVG.Size = new System.Drawing.Size(80, 20);
            this.txtAST_AVG.TabIndex = 7;
            this.txtAST_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt2PT_AVG
            // 
            this.txt2PT_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt2PT_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txt2PT_AVG.Location = new System.Drawing.Point(31, 118);
            this.txt2PT_AVG.Name = "txt2PT_AVG";
            this.txt2PT_AVG.ReadOnly = true;
            this.txt2PT_AVG.Size = new System.Drawing.Size(68, 20);
            this.txt2PT_AVG.TabIndex = 6;
            this.txt2PT_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTIPP_AVG
            // 
            this.txtTIPP_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTIPP_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtTIPP_AVG.Location = new System.Drawing.Point(189, 78);
            this.txtTIPP_AVG.Name = "txtTIPP_AVG";
            this.txtTIPP_AVG.ReadOnly = true;
            this.txtTIPP_AVG.Size = new System.Drawing.Size(88, 20);
            this.txtTIPP_AVG.TabIndex = 5;
            this.txtTIPP_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBLK_AVG
            // 
            this.txtBLK_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBLK_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtBLK_AVG.Location = new System.Drawing.Point(105, 78);
            this.txtBLK_AVG.Name = "txtBLK_AVG";
            this.txtBLK_AVG.ReadOnly = true;
            this.txtBLK_AVG.Size = new System.Drawing.Size(80, 20);
            this.txtBLK_AVG.TabIndex = 4;
            this.txtBLK_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPPG_AVG
            // 
            this.txtPPG_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPPG_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtPPG_AVG.Location = new System.Drawing.Point(152, 37);
            this.txtPPG_AVG.Name = "txtPPG_AVG";
            this.txtPPG_AVG.ReadOnly = true;
            this.txtPPG_AVG.Size = new System.Drawing.Size(80, 20);
            this.txtPPG_AVG.TabIndex = 10;
            this.txtPPG_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTO_AVG
            // 
            this.txtTO_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTO_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtTO_AVG.Location = new System.Drawing.Point(31, 78);
            this.txtTO_AVG.Name = "txtTO_AVG";
            this.txtTO_AVG.ReadOnly = true;
            this.txtTO_AVG.Size = new System.Drawing.Size(68, 20);
            this.txtTO_AVG.TabIndex = 3;
            this.txtTO_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFLS_AVG
            // 
            this.txtFLS_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFLS_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtFLS_AVG.Location = new System.Drawing.Point(180, 159);
            this.txtFLS_AVG.Name = "txtFLS_AVG";
            this.txtFLS_AVG.ReadOnly = true;
            this.txtFLS_AVG.Size = new System.Drawing.Size(97, 20);
            this.txtFLS_AVG.TabIndex = 2;
            this.txtFLS_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSTL_AVG
            // 
            this.txtSTL_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSTL_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtSTL_AVG.Location = new System.Drawing.Point(105, 159);
            this.txtSTL_AVG.Name = "txtSTL_AVG";
            this.txtSTL_AVG.ReadOnly = true;
            this.txtSTL_AVG.Size = new System.Drawing.Size(69, 20);
            this.txtSTL_AVG.TabIndex = 1;
            this.txtSTL_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPPM_AVG
            // 
            this.lblPPM_AVG.AutoSize = true;
            this.lblPPM_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPM_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPPM_AVG.Location = new System.Drawing.Point(87, 20);
            this.lblPPM_AVG.Name = "lblPPM_AVG";
            this.lblPPM_AVG.Size = new System.Drawing.Size(52, 15);
            this.lblPPM_AVG.TabIndex = 21;
            this.lblPPM_AVG.Text = "AVG PPM";
            // 
            // lblPPG_AVG
            // 
            this.lblPPG_AVG.AutoSize = true;
            this.lblPPG_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPG_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPPG_AVG.Location = new System.Drawing.Point(167, 20);
            this.lblPPG_AVG.Name = "lblPPG_AVG";
            this.lblPPG_AVG.Size = new System.Drawing.Size(50, 15);
            this.lblPPG_AVG.TabIndex = 22;
            this.lblPPG_AVG.Text = "AVG PPG";
            // 
            // lblFT_AVG
            // 
            this.lblFT_AVG.AutoSize = true;
            this.lblFT_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFT_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFT_AVG.Location = new System.Drawing.Point(189, 101);
            this.lblFT_AVG.Name = "lblFT_AVG";
            this.lblFT_AVG.Size = new System.Drawing.Size(96, 15);
            this.lblFT_AVG.TabIndex = 20;
            this.lblFT_AVG.Text = "FREE THROW [M/A]";
            // 
            // lblTIPP_AVG
            // 
            this.lblTIPP_AVG.AutoSize = true;
            this.lblTIPP_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTIPP_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTIPP_AVG.Location = new System.Drawing.Point(189, 61);
            this.lblTIPP_AVG.Name = "lblTIPP_AVG";
            this.lblTIPP_AVG.Size = new System.Drawing.Size(59, 15);
            this.lblTIPP_AVG.TabIndex = 17;
            this.lblTIPP_AVG.Text = "AVG TP/PG";
            // 
            // txtPPM_AVG
            // 
            this.txtPPM_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPPM_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtPPM_AVG.Location = new System.Drawing.Point(78, 37);
            this.txtPPM_AVG.Name = "txtPPM_AVG";
            this.txtPPM_AVG.ReadOnly = true;
            this.txtPPM_AVG.Size = new System.Drawing.Size(68, 20);
            this.txtPPM_AVG.TabIndex = 9;
            this.txtPPM_AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFLS_AVG
            // 
            this.lblFLS_AVG.AutoSize = true;
            this.lblFLS_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFLS_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFLS_AVG.Location = new System.Drawing.Point(180, 141);
            this.lblFLS_AVG.Name = "lblFLS_AVG";
            this.lblFLS_AVG.Size = new System.Drawing.Size(108, 15);
            this.lblFLS_AVG.TabIndex = 14;
            this.lblFLS_AVG.Text = "AVG F/PG [DRW/CMT]";
            // 
            // lblTO_AVG
            // 
            this.lblTO_AVG.AutoSize = true;
            this.lblTO_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTO_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTO_AVG.Location = new System.Drawing.Point(31, 61);
            this.lblTO_AVG.Name = "lblTO_AVG";
            this.lblTO_AVG.Size = new System.Drawing.Size(61, 15);
            this.lblTO_AVG.TabIndex = 15;
            this.lblTO_AVG.Text = "AVG TO/PG";
            // 
            // lblAST_AVG
            // 
            this.lblAST_AVG.AutoSize = true;
            this.lblAST_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAST_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAST_AVG.Location = new System.Drawing.Point(105, 101);
            this.lblAST_AVG.Name = "lblAST_AVG";
            this.lblAST_AVG.Size = new System.Drawing.Size(69, 15);
            this.lblAST_AVG.TabIndex = 19;
            this.lblAST_AVG.Text = "AVG ASTS/PG";
            // 
            // lblBLK_AVG
            // 
            this.lblBLK_AVG.AutoSize = true;
            this.lblBLK_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBLK_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBLK_AVG.Location = new System.Drawing.Point(105, 61);
            this.lblBLK_AVG.Name = "lblBLK_AVG";
            this.lblBLK_AVG.Size = new System.Drawing.Size(70, 15);
            this.lblBLK_AVG.TabIndex = 16;
            this.lblBLK_AVG.Text = "AVG BLKS/PG";
            // 
            // lblSTLS_AVG
            // 
            this.lblSTLS_AVG.AutoSize = true;
            this.lblSTLS_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSTLS_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSTLS_AVG.Location = new System.Drawing.Point(31, 141);
            this.lblSTLS_AVG.Name = "lblSTLS_AVG";
            this.lblSTLS_AVG.Size = new System.Drawing.Size(68, 15);
            this.lblSTLS_AVG.TabIndex = 13;
            this.lblSTLS_AVG.Text = "AVG STLS/PG";
            // 
            // lbl3PT_AVG
            // 
            this.lbl3PT_AVG.AutoSize = true;
            this.lbl3PT_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl3PT_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3PT_AVG.Location = new System.Drawing.Point(106, 141);
            this.lbl3PT_AVG.Name = "lbl3PT_AVG";
            this.lbl3PT_AVG.Size = new System.Drawing.Size(64, 15);
            this.lbl3PT_AVG.TabIndex = 12;
            this.lbl3PT_AVG.Text = "AVG 3PT/PG";
            // 
            // lbl2PT_AVG
            // 
            this.lbl2PT_AVG.AutoSize = true;
            this.lbl2PT_AVG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl2PT_AVG.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2PT_AVG.Location = new System.Drawing.Point(31, 101);
            this.lbl2PT_AVG.Name = "lbl2PT_AVG";
            this.lbl2PT_AVG.Size = new System.Drawing.Size(64, 15);
            this.lbl2PT_AVG.TabIndex = 18;
            this.lbl2PT_AVG.Text = "AVG 2PT/PG";
            // 
            // grpPlayerOverallSection
            // 
            this.grpPlayerOverallSection.Controls.Add(this.txtPER_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtFDRWCMT_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtMIN_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txt3PTMA_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txt2PTMA_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtFTMA_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtTIPP_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtTO_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtSTL_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtBLK_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtREB_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtAST_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.txtPTS_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblPER_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblFDRWCMT_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblMIN_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblTIPP_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblFTMA_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblTO_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lbl3PTMA_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lbl2PTMA_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblSTL_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblBLK_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblAST_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblREB_OVRL);
            this.grpPlayerOverallSection.Controls.Add(this.lblPTS_OVRL);
            this.grpPlayerOverallSection.Location = new System.Drawing.Point(5, 18);
            this.grpPlayerOverallSection.Name = "grpPlayerOverallSection";
            this.grpPlayerOverallSection.Size = new System.Drawing.Size(297, 209);
            this.grpPlayerOverallSection.TabIndex = 0;
            this.grpPlayerOverallSection.TabStop = false;
            this.grpPlayerOverallSection.Text = "Overall";
            // 
            // txtPER_OVRL
            // 
            this.txtPER_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPER_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtPER_OVRL.Location = new System.Drawing.Point(125, 184);
            this.txtPER_OVRL.Name = "txtPER_OVRL";
            this.txtPER_OVRL.ReadOnly = true;
            this.txtPER_OVRL.Size = new System.Drawing.Size(149, 20);
            this.txtPER_OVRL.TabIndex = 13;
            this.txtPER_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFDRWCMT_OVRL
            // 
            this.txtFDRWCMT_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFDRWCMT_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtFDRWCMT_OVRL.Location = new System.Drawing.Point(146, 161);
            this.txtFDRWCMT_OVRL.Name = "txtFDRWCMT_OVRL";
            this.txtFDRWCMT_OVRL.ReadOnly = true;
            this.txtFDRWCMT_OVRL.Size = new System.Drawing.Size(128, 20);
            this.txtFDRWCMT_OVRL.TabIndex = 12;
            this.txtFDRWCMT_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMIN_OVRL
            // 
            this.txtMIN_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMIN_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtMIN_OVRL.Location = new System.Drawing.Point(22, 161);
            this.txtMIN_OVRL.Name = "txtMIN_OVRL";
            this.txtMIN_OVRL.ReadOnly = true;
            this.txtMIN_OVRL.Size = new System.Drawing.Size(120, 20);
            this.txtMIN_OVRL.TabIndex = 11;
            this.txtMIN_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt3PTMA_OVRL
            // 
            this.txt3PTMA_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt3PTMA_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txt3PTMA_OVRL.Location = new System.Drawing.Point(194, 119);
            this.txt3PTMA_OVRL.Name = "txt3PTMA_OVRL";
            this.txt3PTMA_OVRL.ReadOnly = true;
            this.txt3PTMA_OVRL.Size = new System.Drawing.Size(80, 20);
            this.txt3PTMA_OVRL.TabIndex = 10;
            this.txt3PTMA_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt2PTMA_OVRL
            // 
            this.txt2PTMA_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt2PTMA_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txt2PTMA_OVRL.Location = new System.Drawing.Point(105, 119);
            this.txt2PTMA_OVRL.Name = "txt2PTMA_OVRL";
            this.txt2PTMA_OVRL.ReadOnly = true;
            this.txt2PTMA_OVRL.Size = new System.Drawing.Size(85, 20);
            this.txt2PTMA_OVRL.TabIndex = 9;
            this.txt2PTMA_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFTMA_OVRL
            // 
            this.txtFTMA_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFTMA_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtFTMA_OVRL.Location = new System.Drawing.Point(22, 119);
            this.txtFTMA_OVRL.Name = "txtFTMA_OVRL";
            this.txtFTMA_OVRL.ReadOnly = true;
            this.txtFTMA_OVRL.Size = new System.Drawing.Size(79, 20);
            this.txtFTMA_OVRL.TabIndex = 8;
            this.txtFTMA_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTIPP_OVRL
            // 
            this.txtTIPP_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTIPP_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtTIPP_OVRL.Location = new System.Drawing.Point(150, 78);
            this.txtTIPP_OVRL.Name = "txtTIPP_OVRL";
            this.txtTIPP_OVRL.ReadOnly = true;
            this.txtTIPP_OVRL.Size = new System.Drawing.Size(124, 20);
            this.txtTIPP_OVRL.TabIndex = 7;
            this.txtTIPP_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTO_OVRL
            // 
            this.txtTO_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTO_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtTO_OVRL.Location = new System.Drawing.Point(85, 78);
            this.txtTO_OVRL.Name = "txtTO_OVRL";
            this.txtTO_OVRL.ReadOnly = true;
            this.txtTO_OVRL.Size = new System.Drawing.Size(57, 20);
            this.txtTO_OVRL.TabIndex = 6;
            this.txtTO_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSTL_OVRL
            // 
            this.txtSTL_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSTL_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtSTL_OVRL.Location = new System.Drawing.Point(22, 78);
            this.txtSTL_OVRL.Name = "txtSTL_OVRL";
            this.txtSTL_OVRL.ReadOnly = true;
            this.txtSTL_OVRL.Size = new System.Drawing.Size(56, 20);
            this.txtSTL_OVRL.TabIndex = 5;
            this.txtSTL_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBLK_OVRL
            // 
            this.txtBLK_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBLK_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtBLK_OVRL.Location = new System.Drawing.Point(216, 38);
            this.txtBLK_OVRL.Name = "txtBLK_OVRL";
            this.txtBLK_OVRL.ReadOnly = true;
            this.txtBLK_OVRL.Size = new System.Drawing.Size(58, 20);
            this.txtBLK_OVRL.TabIndex = 4;
            this.txtBLK_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtREB_OVRL
            // 
            this.txtREB_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtREB_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtREB_OVRL.Location = new System.Drawing.Point(85, 38);
            this.txtREB_OVRL.Name = "txtREB_OVRL";
            this.txtREB_OVRL.ReadOnly = true;
            this.txtREB_OVRL.Size = new System.Drawing.Size(58, 20);
            this.txtREB_OVRL.TabIndex = 2;
            this.txtREB_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAST_OVRL
            // 
            this.txtAST_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAST_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtAST_OVRL.Location = new System.Drawing.Point(151, 38);
            this.txtAST_OVRL.Name = "txtAST_OVRL";
            this.txtAST_OVRL.ReadOnly = true;
            this.txtAST_OVRL.Size = new System.Drawing.Size(56, 20);
            this.txtAST_OVRL.TabIndex = 3;
            this.txtAST_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPTS_OVRL
            // 
            this.txtPTS_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPTS_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F);
            this.txtPTS_OVRL.Location = new System.Drawing.Point(22, 38);
            this.txtPTS_OVRL.Name = "txtPTS_OVRL";
            this.txtPTS_OVRL.ReadOnly = true;
            this.txtPTS_OVRL.Size = new System.Drawing.Size(56, 20);
            this.txtPTS_OVRL.TabIndex = 1;
            this.txtPTS_OVRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPER_OVRL
            // 
            this.lblPER_OVRL.AutoSize = true;
            this.lblPER_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPER_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPER_OVRL.Location = new System.Drawing.Point(22, 186);
            this.lblPER_OVRL.Name = "lblPER_OVRL";
            this.lblPER_OVRL.Size = new System.Drawing.Size(97, 15);
            this.lblPER_OVRL.TabIndex = 26;
            this.lblPER_OVRL.Text = "EFFICIENCY RATING";
            // 
            // lblFDRWCMT_OVRL
            // 
            this.lblFDRWCMT_OVRL.AutoSize = true;
            this.lblFDRWCMT_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFDRWCMT_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFDRWCMT_OVRL.Location = new System.Drawing.Point(146, 143);
            this.lblFDRWCMT_OVRL.Name = "lblFDRWCMT_OVRL";
            this.lblFDRWCMT_OVRL.Size = new System.Drawing.Size(126, 15);
            this.lblFDRWCMT_OVRL.TabIndex = 25;
            this.lblFDRWCMT_OVRL.Text = "TOTAL FOULS [DRW/CMT]";
            // 
            // lblMIN_OVRL
            // 
            this.lblMIN_OVRL.AutoSize = true;
            this.lblMIN_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMIN_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMIN_OVRL.Location = new System.Drawing.Point(22, 143);
            this.lblMIN_OVRL.Name = "lblMIN_OVRL";
            this.lblMIN_OVRL.Size = new System.Drawing.Size(120, 15);
            this.lblMIN_OVRL.TabIndex = 24;
            this.lblMIN_OVRL.Text = "TOTAL MINUTES PLAYED";
            // 
            // lblTIPP_OVRL
            // 
            this.lblTIPP_OVRL.AutoSize = true;
            this.lblTIPP_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTIPP_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTIPP_OVRL.Location = new System.Drawing.Point(150, 60);
            this.lblTIPP_OVRL.Name = "lblTIPP_OVRL";
            this.lblTIPP_OVRL.Size = new System.Drawing.Size(108, 15);
            this.lblTIPP_OVRL.TabIndex = 20;
            this.lblTIPP_OVRL.Text = "TOTAL TIPPED PASSES";
            // 
            // lblFTMA_OVRL
            // 
            this.lblFTMA_OVRL.AutoSize = true;
            this.lblFTMA_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFTMA_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFTMA_OVRL.Location = new System.Drawing.Point(22, 101);
            this.lblFTMA_OVRL.Name = "lblFTMA_OVRL";
            this.lblFTMA_OVRL.Size = new System.Drawing.Size(79, 15);
            this.lblFTMA_OVRL.TabIndex = 21;
            this.lblFTMA_OVRL.Text = "TOTAL FT [M/A]";
            // 
            // lblTO_OVRL
            // 
            this.lblTO_OVRL.AutoSize = true;
            this.lblTO_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTO_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTO_OVRL.Location = new System.Drawing.Point(85, 60);
            this.lblTO_OVRL.Name = "lblTO_OVRL";
            this.lblTO_OVRL.Size = new System.Drawing.Size(54, 15);
            this.lblTO_OVRL.TabIndex = 19;
            this.lblTO_OVRL.Text = "TOTAL TO";
            // 
            // lbl3PTMA_OVRL
            // 
            this.lbl3PTMA_OVRL.AutoSize = true;
            this.lbl3PTMA_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl3PTMA_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3PTMA_OVRL.Location = new System.Drawing.Point(194, 101);
            this.lbl3PTMA_OVRL.Name = "lbl3PTMA_OVRL";
            this.lbl3PTMA_OVRL.Size = new System.Drawing.Size(85, 15);
            this.lbl3PTMA_OVRL.TabIndex = 23;
            this.lbl3PTMA_OVRL.Text = "TOTAL 3PT [M/A]";
            // 
            // lbl2PTMA_OVRL
            // 
            this.lbl2PTMA_OVRL.AutoSize = true;
            this.lbl2PTMA_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl2PTMA_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2PTMA_OVRL.Location = new System.Drawing.Point(105, 101);
            this.lbl2PTMA_OVRL.Name = "lbl2PTMA_OVRL";
            this.lbl2PTMA_OVRL.Size = new System.Drawing.Size(85, 15);
            this.lbl2PTMA_OVRL.TabIndex = 22;
            this.lbl2PTMA_OVRL.Text = "TOTAL 2PT [M/A]";
            // 
            // lblSTL_OVRL
            // 
            this.lblSTL_OVRL.AutoSize = true;
            this.lblSTL_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSTL_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSTL_OVRL.Location = new System.Drawing.Point(22, 60);
            this.lblSTL_OVRL.Name = "lblSTL_OVRL";
            this.lblSTL_OVRL.Size = new System.Drawing.Size(56, 15);
            this.lblSTL_OVRL.TabIndex = 18;
            this.lblSTL_OVRL.Text = "TOTAL STL";
            // 
            // lblBLK_OVRL
            // 
            this.lblBLK_OVRL.AutoSize = true;
            this.lblBLK_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBLK_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBLK_OVRL.Location = new System.Drawing.Point(216, 20);
            this.lblBLK_OVRL.Name = "lblBLK_OVRL";
            this.lblBLK_OVRL.Size = new System.Drawing.Size(58, 15);
            this.lblBLK_OVRL.TabIndex = 17;
            this.lblBLK_OVRL.Text = "TOTAL BLK";
            // 
            // lblAST_OVRL
            // 
            this.lblAST_OVRL.AutoSize = true;
            this.lblAST_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAST_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAST_OVRL.Location = new System.Drawing.Point(150, 20);
            this.lblAST_OVRL.Name = "lblAST_OVRL";
            this.lblAST_OVRL.Size = new System.Drawing.Size(57, 15);
            this.lblAST_OVRL.TabIndex = 16;
            this.lblAST_OVRL.Text = "TOTAL AST";
            // 
            // lblREB_OVRL
            // 
            this.lblREB_OVRL.AutoSize = true;
            this.lblREB_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblREB_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblREB_OVRL.Location = new System.Drawing.Point(85, 20);
            this.lblREB_OVRL.Name = "lblREB_OVRL";
            this.lblREB_OVRL.Size = new System.Drawing.Size(58, 15);
            this.lblREB_OVRL.TabIndex = 15;
            this.lblREB_OVRL.Text = "TOTAL REB";
            // 
            // lblPTS_OVRL
            // 
            this.lblPTS_OVRL.AutoSize = true;
            this.lblPTS_OVRL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPTS_OVRL.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPTS_OVRL.Location = new System.Drawing.Point(22, 20);
            this.lblPTS_OVRL.Name = "lblPTS_OVRL";
            this.lblPTS_OVRL.Size = new System.Drawing.Size(57, 15);
            this.lblPTS_OVRL.TabIndex = 14;
            this.lblPTS_OVRL.Text = "TOTAL PTS";
            // 
            // picPlayer
            // 
            this.picPlayer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picPlayer.Location = new System.Drawing.Point(6, 22);
            this.picPlayer.Name = "picPlayer";
            this.picPlayer.Size = new System.Drawing.Size(134, 162);
            this.picPlayer.TabIndex = 0;
            this.picPlayer.TabStop = false;
            // 
            // frmAdminInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 660);
            this.Controls.Add(this.grpPlayerProfile);
            this.Controls.Add(this.tabTeamList);
            this.Controls.Add(this.mnuStrip);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.mnuStrip;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAdminInterface";
            this.Text = "Royals Basketball Stats Sheet";
            this.Load += new System.EventHandler(this.frmAdminInterface_Load);
            this.mnuStrip.ResumeLayout(false);
            this.mnuStrip.PerformLayout();
            this.tabTeamList.ResumeLayout(false);
            this.tabActiveTeams.ResumeLayout(false);
            this.tabActiveTeams.PerformLayout();
            this.mnuActiveTeams.ResumeLayout(false);
            this.mnuActiveTeams.PerformLayout();
            this.tabArchive.ResumeLayout(false);
            this.tabArchive.PerformLayout();
            this.mnuArchivedTeams.ResumeLayout(false);
            this.mnuArchivedTeams.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.grpPlayerProfile.ResumeLayout(false);
            this.grpPlayerProfile.PerformLayout();
            this.grpPlayerStats.ResumeLayout(false);
            this.grpPlayerAveragesSection.ResumeLayout(false);
            this.grpPlayerAveragesSection.PerformLayout();
            this.grpPlayerOverallSection.ResumeLayout(false);
            this.grpPlayerOverallSection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuFileStartResumeMatch;
        private System.Windows.Forms.ToolStripSeparator mnuFileBorder;
        private System.Windows.Forms.ToolStripMenuItem mnuFileExit;
        private System.Windows.Forms.TabControl tabTeamList;
        private System.Windows.Forms.TabPage tabActiveTeams;
        private System.Windows.Forms.TabPage tabArchive;
        private System.Windows.Forms.GroupBox grpPlayerProfile;
        private System.Windows.Forms.GroupBox grpPlayerStats;
        private System.Windows.Forms.PictureBox picPlayer;
        private System.Windows.Forms.Label lblPTS_OVRL;
        private System.Windows.Forms.GroupBox grpPlayerAveragesSection;
        private System.Windows.Forms.Label lblPPG_AVG;
        private System.Windows.Forms.GroupBox grpPlayerOverallSection;
        private System.Windows.Forms.Label lblBLK_OVRL;
        private System.Windows.Forms.Label lblAST_OVRL;
        private System.Windows.Forms.Label lblREB_OVRL;
        private System.Windows.Forms.Label lblPPM_AVG;
        private System.Windows.Forms.Label lblSTL_OVRL;
        private System.Windows.Forms.Label lblFTMA_OVRL;
        private System.Windows.Forms.Label lblTO_OVRL;
        private System.Windows.Forms.Label lbl3PTMA_OVRL;
        private System.Windows.Forms.Label lbl2PTMA_OVRL;
        private System.Windows.Forms.Label lblTIPP_OVRL;
        private System.Windows.Forms.Label lblMIN_OVRL;
        private System.Windows.Forms.ListBox listArchive;
        private System.Windows.Forms.Label lblFDRWCMT_OVRL;
        private System.Windows.Forms.Label lblSTLS_AVG;
        private System.Windows.Forms.Label lbl3PT_AVG;
        private System.Windows.Forms.Label lbl2PT_AVG;
        private System.Windows.Forms.Label lblAST_AVG;
        private System.Windows.Forms.Label lblBLK_AVG;
        private System.Windows.Forms.Label lblFLS_AVG;
        private System.Windows.Forms.Label lblTO_AVG;
        private System.Windows.Forms.Label lblTIPP_AVG;
        private System.Windows.Forms.Label lblPER_OVRL;
        private System.Windows.Forms.Label lblFT_AVG;
        private System.Windows.Forms.TextBox txtPER_OVRL;
        private System.Windows.Forms.TextBox txtFDRWCMT_OVRL;
        private System.Windows.Forms.TextBox txtMIN_OVRL;
        private System.Windows.Forms.TextBox txt3PTMA_OVRL;
        private System.Windows.Forms.TextBox txt2PTMA_OVRL;
        private System.Windows.Forms.TextBox txtFTMA_OVRL;
        private System.Windows.Forms.TextBox txtTIPP_OVRL;
        private System.Windows.Forms.TextBox txtTO_OVRL;
        private System.Windows.Forms.TextBox txtSTL_OVRL;
        private System.Windows.Forms.TextBox txtBLK_OVRL;
        private System.Windows.Forms.TextBox txtREB_OVRL;
        private System.Windows.Forms.TextBox txtAST_OVRL;
        private System.Windows.Forms.TextBox txtPTS_OVRL;
        private System.Windows.Forms.TextBox txtPPG_AVG;
        private System.Windows.Forms.TextBox txt3PT_AVG;
        private System.Windows.Forms.TextBox txtFT_AVG;
        private System.Windows.Forms.TextBox txtAST_AVG;
        private System.Windows.Forms.TextBox txt2PT_AVG;
        private System.Windows.Forms.TextBox txtTIPP_AVG;
        private System.Windows.Forms.TextBox txtBLK_AVG;
        private System.Windows.Forms.TextBox txtTO_AVG;
        private System.Windows.Forms.TextBox txtFLS_AVG;
        private System.Windows.Forms.TextBox txtSTL_AVG;
        private System.Windows.Forms.TextBox txtPPM_AVG;
        private System.Windows.Forms.MenuStrip mnuArchivedTeams;
        private System.Windows.Forms.ToolStripMenuItem mnuArchivedTeamsUpdate;
        private System.Windows.Forms.TextBox txtArchivedTeamsSearchBar;
        private System.Windows.Forms.TextBox txtActiveTeamsSearchBar;
        private System.Windows.Forms.ListBox listActiveTeams;
        private System.Windows.Forms.MenuStrip mnuActiveTeams;
        private System.Windows.Forms.ToolStripMenuItem mnuActiveTeamsUpdate;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtMatchHistorySearchBar;
        private System.Windows.Forms.ListBox listMatchHistory;
        private System.Windows.Forms.TextBox txtTeamBracket;
        private System.Windows.Forms.Label lblTeamBracket;
        private System.Windows.Forms.TextBox txtJerseyNumber;
        private System.Windows.Forms.Label lblJerseyNumber;
        private System.Windows.Forms.TextBox txtBasketballPosition;
        private System.Windows.Forms.Label lblBasketballPosition;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
    }
}